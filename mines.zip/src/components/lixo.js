//return <View>{rows}</View>;
//const columns = row.map((field, c) => {

// Esse field eh o proprio objeto que representa o campo
// ele contem diversos atributos que sao iguais aos esperados

// Pelo Componente Field do React
//return <Text key={c}>Olar </Text>;
//});
//return <View key={r}> {columns} </View>;
//  return <Text key={r}> Olar </Text>;
//});
//return <View>{rows}</View>;
