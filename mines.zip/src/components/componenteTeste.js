import React from 'react';
import {View, Text} from 'react-native';
import Field from './Field';

export default () => {
  const props2 = {
    board: [
      [1, 2],
      [3, 4],
      [5, 6],
    ],
    rows: 3,
    columns: 2,
  };

  const rows = props2.board.map((element, index) => {
    const columns = Array(props2.columns)
      .fill(0)
      .map((selement, sindex) => {
        return <Field />;
      });
    return <Text> {columns} </Text>;
  });

  return <Text> {rows} </Text>;
};
